aim_map_usp remake for CS:S

I hope you enjoy it :D

- F|4THeAd
http://www.flat-networks.com