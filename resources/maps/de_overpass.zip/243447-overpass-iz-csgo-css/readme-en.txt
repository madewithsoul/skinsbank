Overpass из CS:GO
-------------------------------------------------------------
Работает на всех версиях.
Присутствует баг с мини картой.
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author: Avilas
Was added to the site by user: lk_1997_kl
{tag_tag} De
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
